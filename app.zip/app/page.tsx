"use client";
import React from "react";
import Navbar from "../components/navbar";
import { Container } from "react-bootstrap";
import Row from "react-bootstrap/Row";  
import Col from "react-bootstrap/Col"; 
import Button from "react-bootstrap/Button";
import Image from "next/image"; 
import WorkSection from "../components/worksection";
import ContactSection from "../components/contactsection";
import Servicesection from "../components/servicesection";
import HeroSection from "../components/herosection";
import Footer from "../components/footer";


export default function Home() {
  return (
    <div>
      <Navbar />
      <main>
        <HeroSection />
          <Container className="my-5">
    <Row className="my-4">
        <Col md={6} className="align-self-center pb-4">        
            <div className="mb-4">
                <h2>About Us</h2><br />
                <p>
                    Kami adalah sebuah destinasi kuliner yang lahir
                    dari keragaman tak terbatas ibu kota. Di 
                    MARINATE, kami percaya bahwa
                    setiap selera berhak mendapatkan pengalaman
                    otentik dan tak terlupakan. Kami bukan hanya sebuah restoran;
                    kami adalah sebuah perjalanan kuliner melintasi batas-batas global dan lokal, 
                    semuanya disajikan di jantung kota Jakarta yang dinamis.
                </p>
            </div>
            
            
            <div className="mt-5 mb-4 "> 
                <h2>What We Offer?</h2><br />
               <ul><li><strong>Pilihan Multikultural:</strong> Kami menyajikan spektrum kuliner yang luas, 
                memastikan selalu ada hidangan sempurna untuk setiap mood dan
                 setiap tamu. Nikmati Wagyu premium yang meleleh di mulut,
                  Ramen dengan kuah kolagen yang kaya, hingga Indian Curry 
                  otentik—semuanya tersedia di bawah satu atap.</li><br />
                  <li><strong>Bahan Baku Terbaik:</strong> Kualitas adalah prioritas kami. Setiap bahan dipilih dengan cermat,
                     memastikan kesegaran, rasa, dan standar kebersihan tertinggi.</li><br />
                     <li><strong>Pengalaman Bersantap: </strong>Kami menciptakan suasana yang hangat,
                       stylish, dan nyaman, menjadikannya tempat ideal untuk makan siang bisnis, kumpul keluarga, atau momen romantis </li>
                       </ul>
                      
            </div>
        </Col>
        
     
        <Col md={6} className="ms-auto"> 
            <div style={{ paddingTop: '90px' }}>
                <img 
                    src="/images/restaurant.jpg" 
                    alt="salah lokasi" 
                    className="img-fluid rounded shadow-lg" 
                    style={{ 
                        width: '100%', 
                        height: '100%', 
                        objectFit: 'cover', 
                        marginLeft: '100px' 
                    }} 
                />
            </div>
        </Col>
    </Row>
</Container>
      </main>
      <WorkSection />
      <Servicesection/>
      <section id="contact">
        <ContactSection />
      </section>
      <Footer></Footer>
    </div>
  );
}