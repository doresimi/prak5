'use client'
import { use } from 'react';
import Button from 'react-bootstrap/Button';
import Container from 'react-bootstrap/Container';
import Form from 'react-bootstrap/Form';
import Nav from 'react-bootstrap/Nav';
import Navbar from 'react-bootstrap/Navbar';
import NavDropdown from 'react-bootstrap/NavDropdown';
import Image from 'next/image';


function navbar() {
    return (
        <Navbar expand="lg" className=" py-5 mb-2 text-light"
        style={{backgroundColor:'#8B0000'}}
          data-bs-theme="dark" >
            <Container fluid>
                <NavDropdown 
                    title={
                        <Image 
                            src="/images/account.png" 
                            alt="account"
                            width={54} 
                            height={54} 
                            className="me-4" 
                        />
                    } 
                    id="userAccountDropdown" 
                    align="start"
                    className="account"
                >
                    <NavDropdown.Item href="#change">Change Account</NavDropdown.Item>
                    <NavDropdown.Divider />
                    <NavDropdown.Item href="#logout">Logout</NavDropdown.Item>
                </NavDropdown>
                <Navbar.Toggle aria-controls="navbarScroll"></Navbar.Toggle>
                <Navbar.Collapse id="navbarScroll">
                    <Nav
                        className="me-auto my-5 my-lg-3 custom-nav-links"
                        style = {{ maxHeight: '200px'}}
                        navbarScroll
                    >
                        <NavDropdown title="Locations" id="navbarScrollingDropDown">
                            <NavDropdown.Item href="#action3">Jakarta</NavDropdown.Item>
                            <NavDropdown.Divider></NavDropdown.Divider>
                            <NavDropdown.Item href="#action4">Palembang</NavDropdown.Item>
                            <NavDropdown.Divider></NavDropdown.Divider>
                            <NavDropdown.Item href="#action3">Medan</NavDropdown.Item>
                        </NavDropdown>
                        
                    </Nav>  
                     <a 
                    href="#" 
                    className="flex items-center text-xl font-extrabold text-[#8B0000]"
                    style={{
                      
                        position: 'absolute', 
                        left: '50%',         
                        transform: 'translateX(-50%)', 
                        zIndex: 10,           
                        margin: 'auto',
                        pointerEvents: 'none',
                        fontSize: '50px'
                    }}
                >
                    <Image src="/images/marinate.png" alt="marinate"
                    width={290} height={300} 
                    />
                </a>
              
                

                
               <Form className="d-flex align-items shift-left">  
    <Form.Control 
        type="search"
        placeholder="Search"
        className="me-2 search-input flex-grow-1" 
        aria-label="Search"
        style={{ 
            backgroundColor: 'white', 
            color: 'black'
        }}
    />
    
    <Button 
        className="search-button" 
        style={{
            color: 'white', borderColor: 'white',
            backgroundColor: 'transparent' 
        }} 
    >
        Search
    </Button>
</Form>

 
                </Navbar.Collapse>
            </Container>
        </Navbar>
    )
}

export default navbar;

