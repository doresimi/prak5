'use client';

import { Container, Row, Col, Image } from 'react-bootstrap';

function ServiceSection() {
    return (
        <>
           
            <Container className='my-5'>
                <Row>
                    <Col
                        md={12}
                        className="d-flex flex-column justify-content-start p-5 pb-0"
                        style={{
                            backgroundColor: '#8B0000',
                            color: 'white',
                            borderRadius: '15px',
                            boxShadow: '0 8px 16px rgba(0, 0, 0, 0.3)',
                            position: 'relative',
                            paddingBottom: '200px',
                        }}
                    >
                      
                        <h2 className="mb-4 text-uppercase" style={{
                            fontSize: '3.5rem',
                            fontWeight: 'bold',
                        }}>
                            OUR FOUNDER
                        </h2>

                        <p className="mb-4" style={{
                            maxWidth: '800px',
                            fontSize: '1.25rem',
                            lineHeight: '1.6',
                            textAlign: 'justify'
                        }}>
                            Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.
                            Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.
                        </p>

                        <p className="mb-5" style={{
                            maxWidth: '800px',
                            fontSize: '1.25rem',
                            lineHeight: '1.6',
                            textAlign: 'justify'
                        }}>
                            Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.
                            Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.
                        </p>

                        <div
                            style={{
                                position: 'absolute',
                                right: '0',
                                bottom: '0',
                            }}
                        >
                            <Image
                                src="/images/founder.png"
                                alt="Founder"
                                style={{
                                    width: '400px',
                                    height: 'auto',
                                }}
                            />
                        </div>
                    </Col>
                </Row>
            </Container>

 
    <Container className='my-5'>
        <Row className='myhomies'> 
            
          
            <Col md={12} className="text-center mb-5">
                <h2 className="text-uppercase" style={{
                    fontSize: '3.5rem',
                    fontWeight: 'bold',
                }}>
                    OUR CHEFS
                </h2>
            </Col>
            
            {/* Kartu Chef 1 */}
            <Col md={4} className='mb-3 px-2'>
                <div className='text-center py-3' style={{border: '1px solid #cccccc', borderRadius: '5px' }}>
                    <Image 
                        src="/images/yujin.jpg" 
                        alt="yujin" 
                      
                        style={{ 
                            width: '300px', 
                            height: '300px', 
                            objectFit: 'contain', 
                            marginBottom: '15px',
                           
                        }} 
                    />
                    <br />
                    <h3>yujin</h3>
                    <p>dxhbvdvhjcx
                        jcbvjkcbvjkbcfvjkbxcvjkbfcjkvbjf 
                        dvnjdxv hnjkdvhnjkdvnjdsxvnksd
                        dvnjdxv hnjkdvhnjkdvnjdsxvnksd
                        dvnjdxv hnjkdvhnjkdvnjdsxvnksd
                        dvnjdxv hnjkdvhnjkdvnjdsxvnksd
                        dvnjdxv hnjkdvhnjkdvnjdsxvnksd
                        dvnjdxv hnjkdvhnjkdvnjdsxvnksd
                        dvnjdxv hnjkdvhnjkdvnjdsxvnksd
                    </p>
                </div>
            </Col>
            
            
            <Col md={4} className='mb-3 px-2'>
                <div className='text-center py-3' style={{ border: '1px solid #cccccc', borderRadius: '5px' }}>
                    <Image 
                        src="/images/baeksong.jpg" 
                        alt="Beni" 
                   
                        style={{ 
                            width: '300px', 
                            height: '300px', 
                            objectFit: 'contain', 
                            marginBottom: '15px',
                             
                        }} 
                    />
                    <br />
                    <h3>Baeksong</h3>
                    <p>sfjvnjfkdvnjkfdvjkdvnjksd
                        dhvujvbhjkfbhjkfnbjkfb
                        dnvj khndfcj vknjkfdcv
                        dnvj khndfcj vknjkfdcv
                        dnvj khndfcj vknjkfdcv
                        dnvj khndfcj vknjkfdcv
                        dnvj khndfcj vknjkfdcv
                        dnvj khndfcj vknjkfdcv
                        dnvj khndfcj vknjkfdcv
                        dnvj khndfcj vknjkfdcv
                        dnvj khndfcj vknjkfdcv
                    </p>
                </div>
            </Col>
            
            {/* Kartu Chef 3 */}
            <Col md={4} className='mb-3 px-2'>
                <div className='text-center py-3' style={{ border: '1px solid #cccccc', borderRadius: '5px' }}>
                    <Image 
                        src="/images/ahri.jpg" 
                        alt="Budi" 
                        
                        style={{ 
                            width: '300px', 
                            height: '300px', 
                            objectFit: 'contain', 
                            marginBottom: '15px',
                        }} 
                    />
                    <br />
                    <h3>ahri</h3>
                    <p>cjkdsbv jkhfnd vjknvjkdvjkdvjkbdjbdv jk
                        cnjdsvnjkdcvnjkcf kfckfcnjkcxfd
                        fjoidhdb idnbusoiu
                        fjoidhdb idnbusoiu
                        fjoidhdb idnbusoiu
                        fjoidhdb idnbusoiu
                        fjoidhdb idnbusoiu
                        fjoidhdb idnbusoiu
                        fjoidhdb idnbusoiu
                        fjoidhdb idnbusoiu
                        fjoidhdb idnbusoiu
                    </p>
                </div>
            </Col>
        </Row>
    </Container>
        </>
    );
}
export default ServiceSection;