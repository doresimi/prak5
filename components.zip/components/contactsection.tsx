'use client'
import { Container, Row, Col, Form, Button, Card, Image } from 'react-bootstrap';

function ContactSection() {
    return (
        <Container 
            className='my-5 py-5'
            style={{
                backgroundImage: ` url('/images/reserved.jpg')`, 
                backgroundSize: 'cover',
                backgroundPosition: 'center',
                backgroundRepeat: 'no-repeat',
                minHeight: '800px', 
                backgroundAttachment: 'fixed'
            }}
        >
            <Row className='d-flex justify-content-center gx-3'> 
                
                <Col md={{ span: 7, offset: 1 }} lg={{ span: 7, offset: 1 }} className='mb-4'>
                    <Card className='text-center p-4 shadow-lg h-100'> 
                        <h2 className='text-uppercase fw-bold mb-4'>
                            <span style={{ fontSize: '1.5rem', marginRight: '10px' }}></span> 
                            RESERVE YOUR TABLE
                        </h2>
                        <p className='text-muted'>Book your perfect dining experience with us.</p>
                        
                        <Form className='mt-3 p-3 text-start'>
                            <Row className='mb-3'>
                                <Form.Group as={Col} controlId='formDate'>
                                    <Form.Label className='fw-semibold'>Date</Form.Label>
                                    <Form.Control type='date' required />
                                </Form.Group>
                                <Form.Group as={Col} controlId='formTime'>
                                    <Form.Label className='fw-semibold'>Time</Form.Label>
                                    <Form.Control type='time' defaultValue="19:00" required /> 
                                </Form.Group>
                            </Row>
                            <Row className='mb-3'>
                                <Form.Group as={Col} controlId='formGuests'>
                                    <Form.Label className='fw-semibold'>Number of Guests</Form.Label>
                                    <Form.Control type='number' min='1' max='20' placeholder='e.g., 4' required />
                                </Form.Group>
                                <Form.Group as={Col} controlId='formName'>
                                    <Form.Label className='fw-semibold'>Name</Form.Label>
                                    <Form.Control type='text' placeholder='Enter your name' required />
                                </Form.Group>
                            </Row>

                            <Form.Group className='mb-3' controlId='formEmailOrPhone'>
                                <Form.Label className='fw-semibold'>Email or Phone Number</Form.Label>
                                <Form.Control type='text' placeholder='Enter email or phone' required />
                            </Form.Group>

                            <Form.Group className='mb-4' controlId='formRequests'>
                                <Form.Label className='fw-semibold'>Special Requests (Optional)</Form.Label>
                                <Form.Control as='textarea' rows={3} placeholder='e.g., Dietary restrictions, birthday celebration, table location preference...' />
                            </Form.Group>

                           <Button 
                                type='submit' 
                                className='w-100 fw-bold py-2'
                                
                                style={{ 
                                    backgroundColor: '#8B0000',
                                    borderColor: '#8B0000',    
                                    color: 'white'             
                                }}
                            >
                                BOOK NOW
                            </Button>
                        </Form>
                    </Card>
                </Col>

                <Col md={3} lg={3} className='mb-4'> 
                    <Card className='text-center p-4 shadow-lg h-100 d-flex flex-column justify-content-start'>
                    
                        <h3 className='fw-bold mb-4 border-bottom pb-2'>influencers</h3>
                        
                        <div className='mb-4'>
                            <Image 
                                src="/images/ani.jpg" 
                                alt="Chef Yujin" 
                                fluid 
                                className='rounded-circle mb-3 mx-auto' 
                                style={{ width: '80px', height: '80px', objectFit: 'cover' }}
                            />
                            <p className='text-success small mb-1'> momo | Actress</p>
                            <p className='lead mb-1 fst-italic'>
                            "The most exquisite dining experience! Every dish is a masterpiece. <span className='fw-bold'>Highly recommended!</span>"
                            </p>
                            <footer className="blockquote-footer small"></footer>
                        </div>
                        
                    
                        <div className='mt-3'>
                            <Image 
                                src="/images/jhin.jpg" 
                                alt="Alex" 
                                fluid 
                                className='rounded-circle mb-3 mx-auto' 
                                style={{ width: '80px', height: '80px', objectFit: 'cover' }}
                            />
                            <p className='text-success small mb-1'>— Travel Blogger | jhin</p>
                            <p className='lead mb-1 fst-italic'>
                            "Perfect atmosphere, fantastic service, and <span className='fw-bold'>unforgettable flavors</span>. A must-visit!"
                            </p>
                            <footer className="blockquote-footer small"></footer>
                        </div>
                    </Card>
                </Col>
            </Row>
        </Container>
    );
}

export default ContactSection;