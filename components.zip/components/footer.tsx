'use client'
import { Container, Row, Col, Form, Button, InputGroup } from "react-bootstrap";
import 'bootstrap-icons/font/bootstrap-icons.css';

export default function Footer(){
    // Menentukan warna background dan teks untuk kontras
    const darkMaroon = '#8B0000'; 
    const lightText = 'text-light'; 
    // const mutedLightText = 'text-white-50'; // Tidak digunakan lagi untuk copyright

    return(
        // MENGUBAH BACKGROUND COLOR DI SINI
        <footer id="footer" className="pt-md-4 py-4" style={{backgroundColor: darkMaroon}}>
            <Container>
                
                {/* --- BAGIAN UTAMA FOOTER (LINKS & SEARCH) --- */}
                <Row className="mb-4"> 
                    
                    <Col md={3} className="mb-4">
                        <h3 className={`fw-bold fs-5 mb-3 ${lightText}`}>OUR PRODUCT</h3>
                        <ul className="list-unstyled">
                            <li className="mb-2"> <a href="#" className={`text-decoration-none ${lightText} opacity-75`}>Account</a></li>
                            <li className="mb-2"> <a href="#" className={`text-decoration-none ${lightText} opacity-75`}>Bundle</a></li>
                            <li className="mb-2"> <a href="#" className={`text-decoration-none ${lightText} opacity-75`}>Blog</a></li>
                            <li className="mb-2"> <a href="#" className={`text-decoration-none ${lightText} opacity-75`}>Contact</a></li>
                            <li className="mb-2"> <a href="#" className={`text-decoration-none ${lightText} opacity-75`}>Product</a></li>
                        </ul>
                    </Col>
                    
                    <Col md={3} className="mb-4">
                        <h3 className={`fw-bold fs-5 mb-3 ${lightText}`}>QUICK LINK</h3>
                        <ul className="list-unstyled">
                            <li className="mb-2"> <a href="#" className={`text-decoration-none ${lightText} opacity-75`}>Home</a></li>
                            <li className="mb-2"> <a href="#" className={`text-decoration-none ${lightText} opacity-75`}>About us</a></li>
                            <li className="mb-2"> <a href="#" className={`text-decoration-none ${lightText} opacity-75`}>Service</a></li>
                            <li className="mb-2"> <a href="#" className={`text-decoration-none ${lightText} opacity-75`}>Work</a></li>
                        </ul>
                    </Col>
                    
                    <Col md={3} className="mb-4">
                        <h3 className={`fw-bold fs-5 mb-3 ${lightText}`}>TERM</h3>
                        <ul className="list-unstyled">
                            <li className="mb-2"> <a href="#" className={`text-decoration-none ${lightText} opacity-75`}>Policy</a></li>
                            <li className="mb-2"> <a href="#" className={`text-decoration-none ${lightText} opacity-75`}>Terms of Service</a></li>
                            <li className="mb-2"> <a href="#" className={`text-decoration-none ${lightText} opacity-75`}>Privacy</a></li>
                        </ul>
                    </Col>
                    
                    <Col md={3} className="mb-4">
                        <h3 className={`fw-bold fs-5 mb-3 ${lightText}`}>SEARCH HERE</h3> 
                        <Form className="mb-4"> 
                            <InputGroup>
                                <Form.Control type="text" placeholder="Search here"/>
                                <Button variant="outline-light"> Search</Button> 
                            </InputGroup>
                        </Form>
                        
                        <h3 className={`fw-bold fs-5 mb-3 ${lightText}`}>FOLLOW US</h3>
                        <ul className="list-unstyled d-flex gap-4"> 
                            <li><a href="#" className={lightText}><i className="bi bi-facebook fs-4"></i></a></li>
                            <li><a href="#" className="text-light"><i className="bi bi-instagram fs-4"></i></a></li>
                            <li><a href="#" className="text-light"><i className="bi bi-twitter-x fs-4"></i></a></li>
                            <li><a href="#" className="text-light"><i className="bi bi-tiktok fs-4"></i></a></li> 
                            <li><a href="#" className="text-light"><i className="bi bi-youtube fs-4"></i></a></li>
                        </ul>
                    </Col>
                </Row>
                
                {/* --- BAGIAN COPYRIGHT --- */}
                <Row className="mt-4 pt-3 border-top border-light opacity-50"> 
                    <Col md={12} className="text-center">
                        {/* MENGUBAH TULISAN COPYRIGHT MENJADI TERANG (text-light) */}
                        <p className={`mb-0 small ${lightText}`}> 
                         All rights reserved by @Filipus Susanto
                        </p>
                    </Col>
                </Row>
                
            </Container>
        </footer>
    )
}