"use client"
import Carousel from 'react-bootstrap/Carousel';
import Button from 'react-bootstrap/Button';

interface Slide {
    imageUrl: string;
    title: string; 
    description: string; 
}

const HeroSection = () => {
    const slides: Slide[] = [
        {
            title: "Masakan Indonesia", 
            description: "Lihat Selengkapnya", 
            imageUrl: "/images/masakanindo.JPG",
        },
        { 
            title: "Masakan India", 
            description: "Lihat Selengkapnya",
            imageUrl: "/images/masakanindia.JPG",
        },
        {
            title: "Masakan Jepang", 
            description: "Lihat Selengkapnya",
            imageUrl: "/images/makananjepang.jpg",
        },
        {
            title: "Masakan Barat", 
            description: "Lihat Selengkapnya",
            imageUrl: "/images/masakanbarat.jpg",
        },
    ]



    return (
        <Carousel fade interval={3000} data-bs-theme="light"> 
            {slides.map((slide, index) => (
                <Carousel.Item key={index}>
                    <div 
                     
                        style={{
                            backgroundImage:`url(${slide.imageUrl})`,
                            backgroundSize: "cover",
                            backgroundPosition: "center",
                            height: "70vh",
                        }}>
                    </div>
                    
                   
                    <Carousel.Caption 
                        style={{ 
                            color: 'white',
            
                            top: '60%',            
                            transform: 'translateY(-50%)',
                          
                            left: '0',
                            right: '0'
                        }}
                        className="text-center"
                    >
                      
                        <h3 style={{ fontSize: '3rem' }}>{slide.title}</h3>
                        
                     
                        <Button 
                            variant="light" 
                            href="#" 
                            style={{ marginTop: '15px' }}
                        >
                            {slide.description}
                        </Button>
                        
                    </Carousel.Caption>
                </Carousel.Item>
            )
            )}
        </Carousel>
    )
}
// ...

export default HeroSection;