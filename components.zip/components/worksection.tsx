'use client'
import Button from 'react-bootstrap/Button';
import Card from 'react-bootstrap/Card';
import { Container, Row, Col } from 'react-bootstrap';


interface CardItem {
    id: number;
    title: string;
    text: string;
    imageUrl: string;
    idr: string; 
}


const cardDataTemplates: { fileName: string, title: string, price: string }[] = [
    
    { fileName: "ropang.jpg", title: "indomie kuah plus plus ", price: "Rp 32.000" }, 
    { fileName: "indiancurry.jpg", title: "Indian curry", price: "Rp 75.000" }, 
    { fileName: "macaron.jpg", title: "Sweet Macaroons", price: "Rp 50.000" }, 
    { fileName: "beef.jpg", title: "wagyu beef A5", price: "Rp 480.000" }, 
    { fileName: "ramen.jpg", title: "collagen ramen original", price: "Rp 65.000" }
];


const numImages = cardDataTemplates.length;


const allItems: CardItem[] = Array.from({ length: 5 }, (_, i) => {
    const template = cardDataTemplates[i % numImages];
    
    return {
        id: i + 1,
        title: template.title, 
        text: "Lorem ipsum dolor sit amet consectetur adipisicing elit. Aliquam sunt veritatis voluptas explicabo sapiente.",
        imageUrl: `/images/${template.fileName}`, 
        idr: template.price, 
    };
});


const singleRowData = allItems; 

function WorkSection() {
    const rowItems = singleRowData;

    return (
        <Container className="my-5"> 
            <Row className='mb-4'>
                <Col md={12} className="text-center">
                    <h2> BEST SELLER</h2>
                    <p>our most authentic mixture of local food or international food </p>
                </Col>
            </Row>

            
            <div className="scrolling-container">
                
                <div className="scrolling-track-wrapper">
                    
                    <div className="scrolling-track scroll-right">
                      
                        {[...rowItems, ...rowItems].map((item, index) => (
                            <div key={`single-row-${index}`} className="card-column">
                                <Card className="shadow-sm border-0 w-100">
                                    <Card.Img variant="top" 
                                        src={item.imageUrl} 
                                        alt={item.title}
                                        style={{ height: '180px', objectFit: 'cover' }} 
                                    />
                                    <Card.Body>
                                        <Card.Title className="text-truncate">{item.title}</Card.Title>
                                        <Card.Text as="h5" className="text-danger fw-bold mb-2">
                                            {item.idr}
                                        </Card.Text>
                                        <Card.Text className="text-muted">
                                            {item.text.substring(0, 40)}...
                                        </Card.Text>
                                        <Button variant="danger" style={{ backgroundColor: '#800000', borderColor: '#800000' }}>
                                            Pesan
                                        </Button>
                                    </Card.Body>
                                </Card>
                            </div>
                        ))}
                    </div>
                </div>
            </div>
        </Container>
    )
}

export default WorkSection;